import React from 'react';
import { motion } from 'motion/react';
import { CheckCircle2, AlertCircle, Star, Layout, Briefcase, GraduationCap, Lightbulb, Quote } from 'lucide-react';
import type { ResumeAnalysis } from '../services/gemini';
import { cn } from '../utils/cn';

interface AnalysisResultsProps {
  data: ResumeAnalysis;
}

export const AnalysisResults: React.FC<AnalysisResultsProps> = ({ data }) => {
  const { rating, extraction, suggestions, professionalSummary } = data;

  const scoreColor = (score: number) => {
    if (score >= 8) return 'text-emerald-600 bg-emerald-50 border-emerald-100';
    if (score >= 5) return 'text-amber-600 bg-amber-50 border-amber-100';
    return 'text-rose-600 bg-rose-50 border-rose-100';
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      {/* Score Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className={cn("p-8 rounded-3xl border flex flex-col items-center justify-center text-center", scoreColor(rating.overallScore))}
        >
          <span className="text-sm font-bold uppercase tracking-widest mb-2 opacity-70">Overall Score</span>
          <div className="text-7xl font-black mb-2">{rating.overallScore}<span className="text-2xl opacity-50">/10</span></div>
          <div className="flex gap-1">
            {[...Array(10)].map((_, i) => (
              <Star key={i} className={cn("w-4 h-4", i < rating.overallScore ? "fill-current" : "opacity-20")} />
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="md:col-span-2 bg-white p-8 rounded-3xl border border-zinc-100 shadow-sm"
        >
          <h3 className="text-lg font-bold text-zinc-900 mb-6 flex items-center gap-2">
            <Layout className="w-5 h-5 text-emerald-500" />
            Score Breakdown
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {(Object.entries(rating.breakdown) as [string, number][]).map(([key, value]) => (
              <div key={key} className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="capitalize text-zinc-600 font-medium">{key.replace(/([A-Z])/g, ' $1')}</span>
                  <span className="font-bold text-zinc-900">{value}/10</span>
                </div>
                <div className="h-2 bg-zinc-100 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${value * 10}%` }}
                    transition={{ duration: 1, ease: "easeOut" }}
                    className={cn("h-full rounded-full", value >= 8 ? "bg-emerald-500" : value >= 5 ? "bg-amber-500" : "bg-rose-500")}
                  />
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Professional Summary */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-emerald-900 text-emerald-50 p-8 rounded-3xl relative overflow-hidden"
      >
        <Quote className="absolute -top-4 -right-4 w-32 h-32 text-white/5 rotate-12" />
        <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
          <Lightbulb className="w-5 h-5 text-emerald-400" />
          AI Professional Summary
        </h3>
        <p className="text-xl font-medium leading-relaxed italic">"{professionalSummary}"</p>
      </motion.div>

      {/* Extraction & Suggestions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Extraction */}
        <div className="space-y-6">
          <h3 className="text-2xl font-black text-zinc-900 flex items-center gap-3">
            <CheckCircle2 className="w-7 h-7 text-emerald-500" />
            Extracted Info
          </h3>
          
          <div className="space-y-4">
            <Section title="Skills" items={extraction.skills} icon={<Star className="w-4 h-4" />} />
            <Section title="Experience" items={extraction.experience} icon={<Briefcase className="w-4 h-4" />} />
            <Section title="Education" items={extraction.education} icon={<GraduationCap className="w-4 h-4" />} />
            <Section title="Projects" items={extraction.projects} icon={<Layout className="w-4 h-4" />} />
          </div>
        </div>

        {/* Suggestions */}
        <div className="space-y-6">
          <h3 className="text-2xl font-black text-zinc-900 flex items-center gap-3">
            <AlertCircle className="w-7 h-7 text-amber-500" />
            Improvement Suggestions
          </h3>
          
          <div className="space-y-4">
            <SuggestionSection title="Skills Improvement" items={suggestions.skills} color="emerald" />
            <SuggestionSection title="Project Descriptions" items={suggestions.projects} color="blue" />
            <SuggestionSection title="Action Verbs" items={suggestions.verbs} color="purple" />
            <SuggestionSection title="Formatting" items={suggestions.formatting} color="orange" />
          </div>
        </div>
      </div>
    </div>
  );
};

const Section = ({ title, items, icon }: { title: string; items: string[]; icon: React.ReactNode }) => (
  <div className="bg-white p-6 rounded-2xl border border-zinc-100 shadow-sm">
    <h4 className="text-sm font-bold text-zinc-400 uppercase tracking-widest mb-4 flex items-center gap-2">
      {icon}
      {title}
    </h4>
    <div className="flex flex-wrap gap-2">
      {items.length > 0 ? (
        items.map((item, i) => (
          <span key={i} className="px-3 py-1 bg-zinc-50 text-zinc-700 text-sm rounded-lg border border-zinc-100">
            {item}
          </span>
        ))
      ) : (
        <span className="text-zinc-400 italic text-sm">No {title.toLowerCase()} detected</span>
      )}
    </div>
  </div>
);

const SuggestionSection = ({ title, items, color }: { title: string; items: string[]; color: string }) => {
  const colors: Record<string, string> = {
    emerald: 'bg-emerald-50 text-emerald-700 border-emerald-100',
    blue: 'bg-blue-50 text-blue-700 border-blue-100',
    purple: 'bg-purple-50 text-purple-700 border-purple-100',
    orange: 'bg-orange-50 text-orange-700 border-orange-100',
  };

  return (
    <div className={cn("p-6 rounded-2xl border", colors[color])}>
      <h4 className="font-bold mb-3">{title}</h4>
      <ul className="space-y-2">
        {items.map((item, i) => (
          <li key={i} className="flex gap-2 text-sm">
            <span className="opacity-50">•</span>
            {item}
          </li>
        ))}
      </ul>
    </div>
  );
};
