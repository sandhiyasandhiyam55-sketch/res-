import React, { useState } from 'react';
import { Target, Search, CheckCircle2, XCircle, Loader2, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { matchJobDescription, type JobMatchResult } from '../services/gemini';
import { cn } from '../utils/cn';

interface JobMatchProps {
  resumeText: string;
}

export const JobMatch: React.FC<JobMatchProps> = ({ resumeText }) => {
  const [jobDescription, setJobDescription] = useState('');
  const [isMatching, setIsMatching] = useState(false);
  const [result, setResult] = useState<JobMatchResult | null>(null);

  const handleMatch = async () => {
    if (!jobDescription.trim()) return;
    setIsMatching(true);
    try {
      const matchResult = await matchJobDescription(resumeText, jobDescription);
      setResult(matchResult);
    } catch (error) {
      console.error('Matching error:', error);
    } finally {
      setIsMatching(false);
    }
  };

  return (
    <div className="bg-white p-8 rounded-3xl border border-zinc-100 shadow-sm space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <h3 className="text-2xl font-black text-zinc-900 flex items-center gap-3">
            <Target className="w-7 h-7 text-rose-500" />
            Job Description Match
          </h3>
          <p className="text-zinc-500">Paste a job description to see how well you align.</p>
        </div>
        <button
          onClick={handleMatch}
          disabled={isMatching || !jobDescription.trim()}
          className={cn(
            "px-6 py-3 rounded-xl font-bold flex items-center justify-center gap-2 transition-all duration-300",
            jobDescription.trim() 
              ? "bg-zinc-900 text-white hover:bg-zinc-800 shadow-lg shadow-zinc-200" 
              : "bg-zinc-100 text-zinc-400 cursor-not-allowed"
          )}
        >
          {isMatching ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              Matching...
            </>
          ) : (
            <>
              <Search className="w-5 h-5" />
              Analyze Match
            </>
          )}
        </button>
      </div>

      <textarea
        value={jobDescription}
        onChange={(e) => setJobDescription(e.target.value)}
        placeholder="Paste job title or full job description here..."
        className="w-full h-48 p-6 bg-zinc-50 border border-zinc-100 rounded-2xl focus:ring-2 focus:ring-rose-500 focus:border-transparent transition-all outline-none resize-none text-zinc-700"
      />

      <AnimatePresence>
        {result && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="space-y-8 pt-8 border-t border-zinc-100"
          >
            <div className="flex flex-col items-center text-center gap-4">
              <div className="relative w-32 h-32 flex items-center justify-center">
                <svg className="w-full h-full transform -rotate-90">
                  <circle
                    cx="64"
                    cy="64"
                    r="58"
                    fill="transparent"
                    stroke="currentColor"
                    strokeWidth="8"
                    className="text-zinc-100"
                  />
                  <motion.circle
                    cx="64"
                    cy="64"
                    r="58"
                    fill="transparent"
                    stroke="currentColor"
                    strokeWidth="8"
                    strokeDasharray={364.4}
                    initial={{ strokeDashoffset: 364.4 }}
                    animate={{ strokeDashoffset: 364.4 - (364.4 * result.alignmentPercentage) / 100 }}
                    transition={{ duration: 1.5, ease: "easeOut" }}
                    className={cn(
                      result.alignmentPercentage >= 80 ? "text-emerald-500" : result.alignmentPercentage >= 50 ? "text-amber-500" : "text-rose-500"
                    )}
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-3xl font-black text-zinc-900">{result.alignmentPercentage}%</span>
                  <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Match</span>
                </div>
              </div>
              <p className="text-zinc-600 max-w-lg italic">"{result.explanation}"</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-emerald-50 p-6 rounded-2xl border border-emerald-100">
                <h4 className="text-emerald-900 font-bold mb-4 flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5" />
                  Matching Skills
                </h4>
                <div className="flex flex-wrap gap-2">
                  {result.matchingSkills.map((skill, i) => (
                    <span key={i} className="px-3 py-1 bg-white text-emerald-700 text-xs font-bold rounded-lg border border-emerald-200">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              <div className="bg-rose-50 p-6 rounded-2xl border border-rose-100">
                <h4 className="text-rose-900 font-bold mb-4 flex items-center gap-2">
                  <XCircle className="w-5 h-5" />
                  Missing Skills
                </h4>
                <div className="flex flex-wrap gap-2">
                  {result.missingSkills.map((skill, i) => (
                    <span key={i} className="px-3 py-1 bg-white text-rose-700 text-xs font-bold rounded-lg border border-rose-200">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="bg-zinc-900 text-white p-6 rounded-2xl flex items-center gap-4">
              <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center shrink-0">
                <Sparkles className="w-6 h-6 text-amber-400" />
              </div>
              <div>
                <h4 className="font-bold">Pro Tip</h4>
                <p className="text-sm text-zinc-400">Try incorporating the missing skills into your resume to increase your match percentage!</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
