import React, { useState } from 'react';
import { Mail, Phone, Linkedin, Github, MapPin, ExternalLink, Printer, Search, Loader2, X } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { cn } from '../utils/cn';
import Markdown from 'react-markdown';

interface Education {
  degree: string;
  college: string;
  period?: string;
  percentage: string;
}

interface ResumeData {
  name: string;
  phone: string;
  email: string;
  linkedin: string;
  github: string;
  location: string;
  summary: string;
  education: Education[];
  skills: {
    category: string;
    items: string[];
  }[];
  projects: {
    title: string;
    description: string;
    points: string[];
  }[];
  certifications: string[];
  achievements: string[];
  languages: string[];
}

const defaultData: ResumeData = {
  name: "Sandhiya M",
  phone: "+91 XXXXX XXXXX",
  email: "sandhiya@email.com",
  linkedin: "linkedin.com/in/sandhiya-m",
  github: "github.com/sandhiya-m",
  location: "Tamil Nadu, India",
  summary: "Motivated MCA student with strong programming and problem-solving skills, passionate about software development and modern technologies. Dedicated to building efficient solutions and continuous professional growth.",
  education: [
    {
      degree: "Master of Computer Applications (MCA)",
      college: "Adhiparasakthi College of Arts and Science",
      period: "Year of Completion: 2025",
      percentage: "76%"
    },
    {
      degree: "Higher Secondary (12th Standard)",
      college: "Vidya Vikas Matric Higher Secondary School",
      period: "Year of Completion: 2022",
      percentage: "82%"
    },
    {
      degree: "Secondary School (10th Standard)",
      college: "Vidya Vikas Matric Higher Secondary School",
      period: "Year of Completion: 2020",
      percentage: "77%"
    }
  ],
  skills: [
    { category: "Key Skills", items: ["Python", "C Programming", "HTML & CSS", "MySQL", "GitHub"] }
  ],
  projects: [
    {
      title: "Student Attendance Management System",
      description: "Python & MySQL",
      points: [
        "Developed a simple system to manage and track student attendance records efficiently."
      ]
    },
    {
      title: "AI Resume Analysis Tool",
      description: "AI & NLP",
      points: [
        "Built a basic tool that analyzes resumes and suggests improvements based on industry standards."
      ]
    }
  ],
  certifications: [
    "NSS Volunteer Certificate"
  ],
  achievements: [],
  languages: ["English", "Tamil"]
};

export const ResumeTemplate: React.FC<{ data?: Partial<ResumeData> }> = ({ data = {} }) => {
  const resume = { ...defaultData, ...data };
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [showAnalysisModal, setShowAnalysisModal] = useState(false);

  const handlePrint = () => {
    window.print();
  };

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    setShowAnalysisModal(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const prompt = `
        Act as a professional HR recruiter and resume analyzer.
        Analyze the following resume data and provide:
        1. Overall Resume Score out of 10
        2. Section-wise feedback
        3. Strengths of the resume
        4. Weak areas that need improvement
        5. Suggestions to improve the resume score to at least 9/10
        6. ATS compatibility check
        7. Keyword optimization suggestions
        8. Formatting feedback
        9. Suitability for MCA students applying for entry-level IT jobs

        Resume Data:
        Name: ${resume.name}
        Summary: ${resume.summary}
        Education: ${JSON.stringify(resume.education)}
        Skills: ${JSON.stringify(resume.skills)}
        Projects: ${JSON.stringify(resume.projects)}
        Certifications: ${JSON.stringify(resume.certifications)}
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
      });

      setAnalysis(response.text || "Failed to generate analysis.");
    } catch (error) {
      console.error("Analysis error:", error);
      setAnalysis("An error occurred during analysis. Please try again.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const scores = [
    { label: "Technical Skills", score: 8 },
    { label: "Problem Solving", score: 8 },
    { label: "Communication", score: 7 },
    { label: "Teamwork", score: 9 },
  ];

  const currentDate = new Date().toLocaleDateString('en-US', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  return (
    <div className="max-w-[800px] mx-auto bg-white shadow-xl my-8 print:shadow-none print:my-0 transition-all duration-500 overflow-hidden print:rounded-none border border-zinc-100">
      {/* Print & Analyze Buttons - Hidden during print */}
      <div className="p-4 bg-zinc-50 border-b border-zinc-100 flex justify-between items-center print:hidden">
        <span className="text-xs font-bold text-zinc-400 uppercase tracking-widest">ATS-Friendly Resume</span>
        <div className="flex gap-2">
          <button
            onClick={handleAnalyze}
            disabled={isAnalyzing}
            className="flex items-center gap-2 px-5 py-2 bg-blue-600 text-white rounded-lg font-bold text-xs hover:bg-blue-700 transition-all disabled:opacity-50"
          >
            {isAnalyzing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
            Analyze Resume
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-2 px-5 py-2 bg-zinc-900 text-white rounded-lg font-bold text-xs hover:bg-zinc-800 transition-all"
          >
            <Printer className="w-4 h-4" />
            Print Resume
          </button>
        </div>
      </div>

      {/* Resume Content */}
      <div className="p-12 space-y-8 font-sans text-zinc-900 leading-relaxed">
        {/* Header Section - Centered */}
        <header className="text-center space-y-3">
          <h1 className="text-4xl font-black tracking-tight text-zinc-900 uppercase">
            {resume.name}
          </h1>
          <div className="flex flex-wrap justify-center gap-x-4 gap-y-1 text-[11px] font-bold text-zinc-500 uppercase tracking-wider">
            <span>{resume.phone}</span>
            <span className="text-zinc-300">|</span>
            <span>{resume.email}</span>
            <span className="text-zinc-300">|</span>
            <span>{resume.location}</span>
            <span className="text-zinc-300">|</span>
            <a href={`https://${resume.linkedin}`} className="hover:text-blue-700 transition-colors">LinkedIn</a>
            <span className="text-zinc-300">|</span>
            <a href={`https://${resume.github}`} className="hover:text-blue-700 transition-colors">GitHub</a>
          </div>
        </header>

        {/* Professional Summary */}
        <section className="space-y-2">
          <h2 className="text-sm font-black uppercase tracking-[0.2em] text-blue-900 border-b border-zinc-200 pb-1">Professional Summary</h2>
          <p className="text-sm text-zinc-600 font-medium">
            {resume.summary}
          </p>
        </section>

        {/* Education */}
        <section className="space-y-4">
          <h2 className="text-sm font-black uppercase tracking-[0.2em] text-blue-900 border-b border-zinc-200 pb-1">Education</h2>
          <div className="space-y-4">
            {resume.education.map((edu, i) => (
              <div key={i} className="flex justify-between items-start">
                <div className="space-y-0.5">
                  <h3 className="text-sm font-bold text-zinc-900">{edu.degree}</h3>
                  <p className="text-xs text-zinc-500 font-medium">{edu.college}</p>
                  {edu.period && <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider">{edu.period}</p>}
                </div>
                <div className="text-right">
                  <span className="text-xs font-black text-blue-800">{edu.percentage}</span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Skills & Scores */}
        <div className="grid grid-cols-2 gap-12">
          <section className="space-y-3">
            <h2 className="text-sm font-black uppercase tracking-[0.2em] text-blue-900 border-b border-zinc-200 pb-1">Key Skills</h2>
            <div className="flex flex-wrap gap-2">
              {resume.skills[0].items.map((skill, i) => (
                <span key={i} className="text-sm text-zinc-600 font-medium">• {skill}</span>
              ))}
            </div>
          </section>

          <section className="space-y-3">
            <h2 className="text-sm font-black uppercase tracking-[0.2em] text-blue-900 border-b border-zinc-200 pb-1">Overall Profile Score</h2>
            <div className="grid grid-cols-1 gap-x-8 gap-y-2">
              {scores.map((item, i) => (
                <div key={i} className="flex justify-between items-center text-[10px] font-bold uppercase tracking-widest">
                  <span className="text-zinc-500">{item.label}</span>
                  <span className="text-blue-900">{item.score}/10</span>
                </div>
              ))}
            </div>
          </section>
        </div>

        {/* Projects */}
        <section className="space-y-3">
          <h2 className="text-sm font-black uppercase tracking-[0.2em] text-blue-900 border-b border-zinc-200 pb-1">Projects</h2>
          <div className="space-y-4">
            {resume.projects.map((project, i) => (
              <div key={i} className="space-y-1">
                <h3 className="text-sm font-bold text-zinc-900">{project.title}</h3>
                <ul className="space-y-1">
                  {project.points.map((point, j) => (
                    <li key={j} className="text-sm text-zinc-600 leading-relaxed">• {point}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </section>

        {/* Certifications */}
        <section className="space-y-2">
          <h2 className="text-sm font-black uppercase tracking-[0.2em] text-blue-900 border-b border-zinc-200 pb-1">Certifications</h2>
          <ul className="space-y-1">
            {resume.certifications.map((cert, i) => (
              <li key={i} className="text-sm text-zinc-600 font-medium">• {cert}</li>
            ))}
          </ul>
        </section>

        {/* Declaration */}
        <section className="space-y-2 pt-4">
          <h2 className="text-sm font-black uppercase tracking-[0.2em] text-blue-900 border-b border-zinc-200 pb-1">Declaration</h2>
          <p className="text-xs text-zinc-500 italic">
            I hereby declare that the above information is true and correct to the best of my knowledge and belief.
          </p>
        </section>

        {/* Signature Section */}
        <footer className="flex justify-between items-end pt-8">
          <div className="space-y-1 text-xs font-bold text-zinc-500 uppercase tracking-widest">
            <p>Place: Tamil Nadu</p>
            <p>Date: {currentDate}</p>
          </div>
          <div className="text-center space-y-2">
            <div className="w-32 border-b border-zinc-900 mx-auto" />
            <p className="text-xs font-black uppercase tracking-widest text-zinc-900">Signature</p>
            <p className="text-[10px] font-bold text-zinc-400">{resume.name}</p>
          </div>
        </footer>
      </div>

      {/* Footer Info */}
      <div className="p-6 bg-zinc-50 text-center print:hidden border-t border-zinc-100">
        <p className="text-[10px] text-zinc-400 font-black uppercase tracking-[0.4em]">Optimized for ATS & Recruiter Review</p>
      </div>

      {/* Analysis Modal */}
      {showAnalysisModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[80vh] flex flex-col overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-6 border-b border-zinc-100 flex justify-between items-center bg-zinc-50/50">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-100 text-blue-600 rounded-lg">
                  <Search className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-zinc-900 uppercase tracking-tight text-sm">Resume Analysis</h3>
                  <p className="text-[9px] text-zinc-400 font-bold uppercase tracking-widest">Powered by Gemini AI</p>
                </div>
              </div>
              <button 
                onClick={() => setShowAnalysisModal(false)}
                className="p-2 hover:bg-zinc-100 rounded-full transition-colors"
              >
                <X className="w-5 h-5 text-zinc-400" />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-8">
              {isAnalyzing ? (
                <div className="flex flex-col items-center justify-center py-12 space-y-4">
                  <Loader2 className="w-10 h-10 text-blue-600 animate-spin" />
                  <p className="text-xs font-bold text-zinc-500 uppercase tracking-widest animate-pulse">Analyzing your profile...</p>
                </div>
              ) : (
                <div className="prose prose-sm max-w-none prose-zinc prose-headings:text-blue-900 prose-headings:uppercase prose-headings:tracking-widest prose-headings:font-black prose-p:text-zinc-600 prose-li:text-zinc-600">
                  <Markdown>{analysis || ""}</Markdown>
                </div>
              )}
            </div>

            <div className="p-6 border-t border-zinc-100 bg-zinc-50/50 flex justify-end">
              <button
                onClick={() => setShowAnalysisModal(false)}
                className="px-6 py-2 bg-zinc-900 text-white rounded-lg font-bold text-xs hover:bg-zinc-800 transition-all uppercase tracking-widest"
              >
                Close Analysis
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
