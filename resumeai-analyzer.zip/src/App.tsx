import { useState } from 'react';
import { FileUploader } from './components/FileUploader';
import { AnalysisResults } from './components/AnalysisResults';
import { JobMatch } from './components/JobMatch';
import { ResumeTemplate } from './components/ResumeTemplate';
import { extractTextFromPdf } from './utils/pdf';
import { analyzeResume, type ResumeAnalysis } from './services/gemini';
import { Sparkles, FileSearch, RefreshCw, Github, Layout } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

type Tab = 'analyze' | 'template';

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('analyze');
  const [isProcessing, setIsProcessing] = useState(false);
  const [resumeText, setResumeText] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<ResumeAnalysis | null>(null);

  const handleFileSelect = async (file: File) => {
    setIsProcessing(true);
    try {
      const text = await extractTextFromPdf(file);
      setResumeText(text);
      const result = await analyzeResume(text);
      setAnalysis(result);
    } catch (error) {
      console.error('Processing error:', error);
      alert('Failed to process resume. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const reset = () => {
    setResumeText(null);
    setAnalysis(null);
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] text-zinc-900 font-sans selection:bg-emerald-200">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-zinc-100">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center">
              <Sparkles className="text-white w-6 h-6" />
            </div>
            <span className="text-xl font-black tracking-tighter">ResumeAI</span>
          </div>
          
          <div className="flex items-center bg-zinc-100 p-1 rounded-xl">
            <button
              onClick={() => setActiveTab('analyze')}
              className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${
                activeTab === 'analyze' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-500 hover:text-zinc-700'
              }`}
            >
              Analyzer
            </button>
            <button
              onClick={() => setActiveTab('template')}
              className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${
                activeTab === 'template' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-500 hover:text-zinc-700'
              }`}
            >
              Resume Builder
            </button>
          </div>

          <div className="flex items-center gap-6">
            <a 
              href="https://github.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="p-2 bg-zinc-100 rounded-lg hover:bg-zinc-200 transition-colors"
            >
              <Github className="w-5 h-5" />
            </a>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-6 py-12">
        <AnimatePresence mode="wait">
          {activeTab === 'analyze' ? (
            <motion.div
              key="analyze"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-12"
            >
              {!analysis ? (
                <div className="text-center space-y-8 max-w-3xl mx-auto py-12">
                  <div className="space-y-4">
                    <div className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-50 text-emerald-700 rounded-full text-xs font-black uppercase tracking-widest">
                      <Sparkles className="w-3 h-3" />
                      AI-Powered Analysis
                    </div>
                    <h1 className="text-6xl md:text-7xl font-black tracking-tight text-zinc-900 leading-[0.9]">
                      Optimize your resume for <span className="text-emerald-600">success.</span>
                    </h1>
                    <p className="text-xl text-zinc-500 font-medium max-w-xl mx-auto">
                      Upload your resume and get instant AI-powered feedback, score, and job matching.
                    </p>
                  </div>

                  <FileUploader onFileSelect={handleFileSelect} isProcessing={isProcessing} />

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-8">
                    {[
                      { label: "PDF Extraction", icon: <FileSearch className="w-4 h-4" /> },
                      { label: "Skill Detection", icon: <Sparkles className="w-4 h-4" /> },
                      { label: "JD Matching", icon: <RefreshCw className="w-4 h-4" /> },
                      { label: "AI Summary", icon: <Sparkles className="w-4 h-4" /> },
                    ].map((feature, i) => (
                      <div key={i} className="flex items-center justify-center gap-2 text-xs font-bold text-zinc-400 uppercase tracking-wider">
                        {feature.icon}
                        {feature.label}
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="space-y-12">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <h2 className="text-3xl font-black tracking-tight">Analysis Report</h2>
                      <p className="text-zinc-500">Detailed insights and suggestions for your resume.</p>
                    </div>
                    <button
                      onClick={reset}
                      className="flex items-center gap-2 px-6 py-3 bg-white border border-zinc-200 rounded-xl font-bold hover:bg-zinc-50 transition-all shadow-sm"
                    >
                      <RefreshCw className="w-4 h-4" />
                      Analyze New Resume
                    </button>
                  </div>

                  <AnalysisResults data={analysis} />
                  
                  {resumeText && (
                    <JobMatch resumeText={resumeText} />
                  )}
                </div>
              )}
            </motion.div>
          ) : (
            <motion.div
              key="template"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div className="text-center space-y-4 max-w-2xl mx-auto mb-12">
                <h2 className="text-4xl font-black tracking-tight">Professional Resume Template</h2>
                <p className="text-zinc-500 font-medium">
                  A clean, ATS-friendly template designed for Computer Science students. 
                  Edit the details and print to PDF.
                </p>
              </div>
              <ResumeTemplate />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-100 py-12 mt-24 print:hidden">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-zinc-900 rounded-lg flex items-center justify-center">
              <Sparkles className="text-white w-5 h-5" />
            </div>
            <span className="font-black tracking-tighter">ResumeAI</span>
          </div>
          <p className="text-sm text-zinc-400 font-medium">
            © 2026 ResumeAI Analyzer. Built with Google Gemini.
          </p>
          <div className="flex gap-6">
            <a href="#" className="text-sm font-bold text-zinc-400 hover:text-zinc-900">Privacy</a>
            <a href="#" className="text-sm font-bold text-zinc-400 hover:text-zinc-900">Terms</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
