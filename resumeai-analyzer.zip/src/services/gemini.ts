import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface ResumeAnalysis {
  extraction: {
    skills: string[];
    projects: string[];
    keywords: string[];
    education: string[];
    experience: string[];
  };
  rating: {
    overallScore: number;
    breakdown: {
      clarity: number;
      formatting: number;
      skillsRelevance: number;
      projectImpact: number;
      professionalTone: number;
    };
  };
  suggestions: {
    skills: string[];
    projects: string[];
    verbs: string[];
    formatting: string[];
  };
  professionalSummary: string;
}

export interface JobMatchResult {
  matchingSkills: string[];
  missingSkills: string[];
  alignmentPercentage: number;
  explanation: string;
}

export async function analyzeResume(resumeText: string): Promise<ResumeAnalysis> {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Analyze the following resume text and provide a structured JSON response.
    
    Resume Text:
    ${resumeText}
    
    Requirements:
    1. Extract skills, projects, keywords, education, and experience.
    2. Rate the resume out of 10 on clarity, formatting, skills relevance, project impact, and professional tone.
    3. Provide section-wise suggestions for improvement.
    4. Generate a concise 2-line professional summary.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          extraction: {
            type: Type.OBJECT,
            properties: {
              skills: { type: Type.ARRAY, items: { type: Type.STRING } },
              projects: { type: Type.ARRAY, items: { type: Type.STRING } },
              keywords: { type: Type.ARRAY, items: { type: Type.STRING } },
              education: { type: Type.ARRAY, items: { type: Type.STRING } },
              experience: { type: Type.ARRAY, items: { type: Type.STRING } },
            },
            required: ["skills", "projects", "keywords", "education", "experience"],
          },
          rating: {
            type: Type.OBJECT,
            properties: {
              overallScore: { type: Type.NUMBER },
              breakdown: {
                type: Type.OBJECT,
                properties: {
                  clarity: { type: Type.NUMBER },
                  formatting: { type: Type.NUMBER },
                  skillsRelevance: { type: Type.NUMBER },
                  projectImpact: { type: Type.NUMBER },
                  professionalTone: { type: Type.NUMBER },
                },
                required: ["clarity", "formatting", "skillsRelevance", "projectImpact", "professionalTone"],
              },
            },
            required: ["overallScore", "breakdown"],
          },
          suggestions: {
            type: Type.OBJECT,
            properties: {
              skills: { type: Type.ARRAY, items: { type: Type.STRING } },
              projects: { type: Type.ARRAY, items: { type: Type.STRING } },
              verbs: { type: Type.ARRAY, items: { type: Type.STRING } },
              formatting: { type: Type.ARRAY, items: { type: Type.STRING } },
            },
            required: ["skills", "projects", "verbs", "formatting"],
          },
          professionalSummary: { type: Type.STRING },
        },
        required: ["extraction", "rating", "suggestions", "professionalSummary"],
      },
    },
  });

  return JSON.parse(response.text || "{}");
}

export async function matchJobDescription(resumeText: string, jobDescription: string): Promise<JobMatchResult> {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Compare the following resume with the job description and provide a structured JSON response.
    
    Resume Text:
    ${resumeText}
    
    Job Description:
    ${jobDescription}
    
    Requirements:
    1. Identify matching skills.
    2. Identify missing skills.
    3. Calculate alignment percentage.
    4. Provide a brief explanation.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          matchingSkills: { type: Type.ARRAY, items: { type: Type.STRING } },
          missingSkills: { type: Type.ARRAY, items: { type: Type.STRING } },
          alignmentPercentage: { type: Type.NUMBER },
          explanation: { type: Type.STRING },
        },
        required: ["matchingSkills", "missingSkills", "alignmentPercentage", "explanation"],
      },
    },
  });

  return JSON.parse(response.text || "{}");
}
