# ResumeAI Analyzer

ResumeAI Analyzer is an AI-powered tool designed to help job seekers optimize their resumes. It uses Google's Gemini AI to extract information, rate resumes, provide improvement suggestions, and match resumes against job descriptions.

## Features

1.  **Resume Upload**: Supports PDF format with automatic text extraction using `pdfjs-dist`.
2.  **Information Extraction**: Automatically detects and extracts Skills, Projects, Keywords, Education, and Experience.
3.  **Rating System**: Provides a score out of 10 based on Clarity, Formatting, Skills Relevance, Project Impact, and Professional Tone.
4.  **Improvement Suggestions**: Section-wise suggestions for skills, project descriptions, action verbs, and formatting.
5.  **AI Professional Summary**: Generates a concise 2-line summary for the top of the resume.
6.  **Job Description Matching**: Compare your resume against a specific job title or description to see matching skills, missing skills, and an alignment percentage.
7.  **Resume Re-evaluation**: Easily upload a revised version to see your improved score.

## Tech Stack

-   **Frontend**: React 19, Tailwind CSS 4
-   **AI**: Google Gemini 3 Flash
-   **PDF Processing**: PDF.js
-   **Icons**: Lucide React
-   **Animations**: Motion

## Setup Instructions

1.  **Clone the repository**:
    ```bash
    git clone <repository-url>
    cd resume-ai-analyzer
    ```

2.  **Install dependencies**:
    ```bash
    npm install
    ```

3.  **Configure Environment Variables**:
    Create a `.env` file in the root directory and add your Gemini API key:
    ```env
    GEMINI_API_KEY=your_api_key_here
    ```

4.  **Start the development server**:
    ```bash
    npm run dev
    ```

5.  **Build for production**:
    ```bash
    npm run build
    ```

## Usage

1.  Upload your resume in PDF format.
2.  Wait for the AI to analyze and provide a detailed report.
3.  Review the score, extracted info, and suggestions.
4.  Paste a job description in the "Job Description Match" section to see how well you fit.
5.  Apply the suggestions to your resume and re-upload to see your score improve!
